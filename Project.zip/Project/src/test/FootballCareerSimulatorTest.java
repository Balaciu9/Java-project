package org.example.project;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import static org.junit.jupiter.api.Assertions.*;

class FootballCareerSimulatorTest {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/football career";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "1234";
    private Connection connection;

    @BeforeEach
    void setUp() throws Exception {
        connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        clearTestData();
    }

    @AfterEach
    void tearDown() throws Exception {
        clearTestData();
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }

    private void clearTestData() throws Exception {
        try (PreparedStatement clearPlayers = connection.prepareStatement("DELETE FROM Players");
             PreparedStatement clearSeasonStats = connection.prepareStatement("DELETE FROM SeasonStats")) {
            clearSeasonStats.executeUpdate();
            clearPlayers.executeUpdate();
        }
    }

    @Test
    void testInitializePlayer() throws Exception {
        String playerName = "John Doe";

        int playerId = FootballCareerSimulator.initializePlayer(connection, playerName);

        try (PreparedStatement query = connection.prepareStatement("SELECT * FROM Players WHERE PlayerID = ?")) {
            query.setInt(1, playerId);
            ResultSet resultSet = query.executeQuery();

            assertTrue(resultSet.next());
            assertEquals(playerName, resultSet.getString("Name"));
            assertEquals(18, resultSet.getInt("CurrentAge"));
            assertEquals("UTA", resultSet.getString("CurrentClub"));
        }
    }

    @Test
    void testUpdateSeasonStats() throws Exception {
        String playerName = "John Doe";
        int playerId = FootballCareerSimulator.initializePlayer(connection, playerName);

        FootballCareerSimulator.updateSeasonStats(connection, playerId, 19, 20, 10, "League Title");

        try (PreparedStatement query = connection.prepareStatement("SELECT * FROM SeasonStats WHERE PlayerID = ?")) {
            query.setInt(1, playerId);
            ResultSet resultSet = query.executeQuery();

            assertTrue(resultSet.next());
            assertEquals(19, resultSet.getInt("Age"));
            assertEquals(20, resultSet.getInt("GoalsScored"));
            assertEquals(10, resultSet.getInt("Assists"));
            assertEquals("League Title", resultSet.getString("TrophiesWon"));
        }
    }

    @Test
    void testUpdatePlayerClub() throws Exception {
        String playerName = "John Doe";
        int playerId = FootballCareerSimulator.initializePlayer(connection, playerName);

        String newClub = "Real Madrid";
        int newClubId = 2;

        FootballCareerSimulator.updatePlayerClub(connection, playerId, newClub, newClubId);

        try (PreparedStatement query = connection.prepareStatement("SELECT * FROM Players WHERE PlayerID = ?")) {
            query.setInt(1, playerId);
            ResultSet resultSet = query.executeQuery();

            assertTrue(resultSet.next());
            assertEquals(newClub, resultSet.getString("CurrentClub"));
            assertEquals(newClubId, resultSet.getInt("ClubID"));
        }
    }
}
