package org.example.project;

import java.sql.*;
import java.util.Random;
import java.util.Scanner;

public class FootballCareerSimulator {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/football career";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "1234";

    public static void main(String[] args) {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            Scanner scanner = new Scanner(System.in);
            Random random = new Random();

            System.out.println("Welcome to the Football Career Simulator!");
            System.out.print("Enter your player's name (1-50 characters, letters and spaces only): ");
            String playerName = scanner.nextLine();

            while (!isValidName(playerName)) {
                System.out.println("Invalid name. Please use only letters and spaces, and ensure it's between 1 and 50 characters.");
                System.out.print("Enter your player's name: ");
                playerName = scanner.nextLine();
            }

            int playerID = initializePlayer(connection, playerName);
            String currentClub = "UTA";
            int age = 18;

            while (age <= 35) {
                System.out.println("\n--- Season: Age " + age + " ---");
                currentClub = handleSeason(connection, playerID, age, currentClub, random, scanner);
                age++;
            }

            displayCareerSummary(connection, playerID);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static boolean isValidName(String name) {
        return name.matches("[A-Za-z ]{1,50}");
    }

    static int initializePlayer(Connection connection, String playerName) throws SQLException {
        String insertPlayerSQL = "INSERT INTO Players (Name, CurrentAge, CurrentClub, TotalGoals, TotalAssists) VALUES (?, 18, 'UTA', 0, 0)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(insertPlayerSQL, Statement.RETURN_GENERATED_KEYS)) {
            preparedStatement.setString(1, playerName);
            preparedStatement.executeUpdate();

            ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
            if (generatedKeys.next()) {
                return generatedKeys.getInt(1);
            } else {
                throw new SQLException("Failed to initialize player, no ID obtained.");
            }
        }
    }

    private static String handleSeason(Connection connection, int playerID, int age, String currentClub, Random random, Scanner scanner) throws SQLException {
        int seasonGoals = random.nextInt(60);
        int seasonAssists = random.nextInt(30);
        boolean wonTrophy = random.nextBoolean();
        String trophy = wonTrophy ? "League Title" : "None";

        updateSeasonStats(connection, playerID, age, seasonGoals, seasonAssists, trophy);
        updateCumulativeStats(connection, playerID, seasonGoals, seasonAssists);
        updatePlayerAge(connection, playerID, age);

        System.out.println("\nSeason Summary:");
        System.out.println("Age: " + age);
        System.out.println("Club: " + currentClub);
        System.out.println("Goals Scored: " + seasonGoals);
        System.out.println("Assists: " + seasonAssists);
        System.out.println("Trophies Won: " + trophy);

        currentClub = handleTransferDecisions(connection, playerID, currentClub, random, scanner);

        return currentClub;
    }

    static void updateSeasonStats(Connection connection, int playerID, int age, int goals, int assists, String trophy) throws SQLException {
        String insertStatsSQL = "INSERT INTO SeasonStats (PlayerID, Age, GoalsScored, Assists, TrophiesWon) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(insertStatsSQL)) {
            preparedStatement.setInt(1, playerID);
            preparedStatement.setInt(2, age);
            preparedStatement.setInt(3, goals);
            preparedStatement.setInt(4, assists);
            preparedStatement.setString(5, trophy);
            preparedStatement.executeUpdate();
        }
    }

    private static void updateCumulativeStats(Connection connection, int playerID, int seasonGoals, int seasonAssists) throws SQLException {
        String updateStatsSQL = "UPDATE Players SET TotalGoals = TotalGoals + ?, TotalAssists = TotalAssists + ? WHERE PlayerID = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(updateStatsSQL)) {
            preparedStatement.setInt(1, seasonGoals);
            preparedStatement.setInt(2, seasonAssists);
            preparedStatement.setInt(3, playerID);
            preparedStatement.executeUpdate();
        }
    }

    private static void updatePlayerAge(Connection connection, int playerID, int age) throws SQLException {
        String updateAgeSQL = "UPDATE Players SET CurrentAge = ? WHERE PlayerID = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(updateAgeSQL)) {
            preparedStatement.setInt(1, age);
            preparedStatement.setInt(2, playerID);
            preparedStatement.executeUpdate();
        }
    }

    private static String handleTransferDecisions(Connection connection, int playerID, String currentClub, Random random, Scanner scanner) throws SQLException {
        String updatedCurrentClub = currentClub;

        String fetchClubsSQL = "SELECT ClubID, ClubName FROM Clubs WHERE ClubName != ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(fetchClubsSQL)) {
            preparedStatement.setString(1, currentClub);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                int transferOffers = random.nextInt(3) + 1;
                String[] clubsOffered = new String[transferOffers];
                int[] clubIDs = new int[transferOffers];
                int counter = 0;

                while (resultSet.next() && counter < transferOffers) {
                    clubsOffered[counter] = resultSet.getString("ClubName");
                    clubIDs[counter] = resultSet.getInt("ClubID");
                    System.out.println(counter + 1 + ". " + clubsOffered[counter]);
                    counter++;
                }

                System.out.print("\nWould you like to transfer to another club? (yes/no): ");
                String decision = scanner.nextLine();

                if (decision.equalsIgnoreCase("yes")) {
                    System.out.print("Which club would you like to join (1-" + transferOffers + "): ");
                    int clubChoice = Integer.parseInt(scanner.nextLine()) - 1;

                    if (clubChoice >= 0 && clubChoice < transferOffers) {
                        String chosenClub = clubsOffered[clubChoice];
                        int chosenClubID = clubIDs[clubChoice];
                        updatePlayerClub(connection, playerID, chosenClub, chosenClubID);
                        updatedCurrentClub = chosenClub;
                        System.out.println("You have transferred to " + chosenClub + ".");
                    } else {
                        System.out.println("Invalid choice. Staying with your current club.");
                    }
                } else {
                    System.out.println("You decided to stay with your current club.");
                }
            }
        }

        return updatedCurrentClub;
    }

    static void updatePlayerClub(Connection connection, int playerID, String newClub, int newClubID) throws SQLException {
        String updateClubSQL = "UPDATE Players SET CurrentClub = ?, ClubID = ? WHERE PlayerID = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(updateClubSQL)) {
            preparedStatement.setString(1, newClub);
            preparedStatement.setInt(2, newClubID);
            preparedStatement.setInt(3, playerID);
            preparedStatement.executeUpdate();
        }
    }

    private static void displayCareerSummary(Connection connection, int playerID) throws SQLException {
        String careerSummarySQL = "SELECT TotalGoals, TotalAssists FROM Players WHERE PlayerID = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(careerSummarySQL)) {
            preparedStatement.setInt(1, playerID);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    int totalGoals = resultSet.getInt("TotalGoals");
                    int totalAssists = resultSet.getInt("TotalAssists");

                    System.out.println("\nCareer Summary:");
                    System.out.println("Total Goals Scored: " + totalGoals);
                    System.out.println("Total Assists: " + totalAssists);
                }
            }
        }
    }
}
